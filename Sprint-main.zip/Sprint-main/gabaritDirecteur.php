<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
	<head>
		<title>Directeur</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 		<link rel="stylesheet" type="text/css" href="" /> 
		<script type="text/javascript">
			function AfficheSpecialite(){
				var list = document.getElementById('cat');
				var INDEX = list.selectedIndex;
				if(list[INDEX].value=="med"){
					document.getElementById("specialite").innerHTML="<p>Spécialité : <select name='spe'><option value='chi'>Chirurgien</option><option value='gen'>Généraliste</option></select></p>";
				}
				else{
					document.getElementById("specialite").innerHTML="";
				}		
			}
		</script>
    </head>
    <body>
	<h1>Directeur</h1>
	<form id="formuDirecteur1" action="clinique.php" method="post">
			<fieldset>
				<legend>Créer Personnel</legend>
				<p><label>Nom :</label><input type="text" id="nomP" name="nomP"/></p>
				<p><label>Prénom :</label><input type="text" id="prenomP" name="prenomP"/></p>
				<p><label> Login : </label> <input type="text" id="loginP" name="loginP" /></p>
				<p><label> Mot de passe  : </label> <input type="password" id="mdpP" name="mdpP" /></p>
				<p>
					<label>Catégorie :</label>
					<a href="javascript:;" onBlur="AfficheSpecialite();">
						<select id='cat'>
							<option value='med'>Médecin</option>
							<option value='dir'>Directeur</option>
							<option value='age'>Agent</option>
						</select>
					</a>
				</p>
				<div id="specialite"></div>
				<p> <input type="submit" id="creerP" value="Créer" name="creerP"/>  <input type="reset" value="Effacer" name="efface" /> </p>
			</fieldset>
	</form>
	<form id="formuDirecteur1" action="clinique.php" method="post">
		
			<fieldset>
				<legend>Modifier Personnel</legend>
				<p><label> Id Personnel : </label> <input type="text" id="idP" name="idP" /></p>
				<p><label> Login : </label> <input type="text" id="loginP" name="loginP" /></p>
				<p><label> Mot de passe  : </label> <input type="password" id="mdpP" name="mdpP" /></p>
				<p> <input type="submit" value="Modifier" name="modifierP" />  <input type="reset" value="Effacer" name="efface" /> </p>
			</fieldset>
	</form>
	<form id="formuDirecteur2" action="clinique.php" method="post">
		
			<fieldset>
				<legend>Créer Motifs de RDV</legend>
				<p><label> Motif : </label> <input type="text" id="motif" name="motif" /></p>
				<p><label> Prix : </label> <input type="text" id="prix" name="prix" /></p>
				<!-- mettre du php avec liste déroulante pour les pièces et consignes -->
				<p><label> Ajouter pièce : </label> <input type="text" id="ajoutP" name="ajoutP" /> <input type="submit" value="Ajouter" name="ajouter" /></p>
				<p><label> Ajouter consigne : </label> <input type="text" id="ajoutC" name="ajoutC" size="50"/> <input type="submit" value="Ajouter " name="ajouterConsigne" /></p>
				<p><input type="submit" value="Créer" name="creerM" /> 
					
					<input type="reset" value="Effacer" name="efface" /> </p>
			</fieldset>
	</form>		
	
	<form id="formuDirecteur5" action="clinique.php" method="post"> 		
			<fieldset>
				<legend>Modifier Motifs de RDV</legend>
				<p><label> Motif : </label> <input type="text" id="motif" name="motif" /></p>
				<p><label> Prix : </label> <input type="text" id="prix" name="prix" /></p>
				<!-- mettre du php avec liste déroulante pour les pièces et consignes -->
				
				<p>
					<input type="submit" value="Modifier" name="modifierM" />
					
			</p>
			</fieldset>
	</form>
	
	<form id="formuDirecteur6" action="clinique.php" method="post">
		
		<fieldset>
				<legend>Afficher Motifs de RDV </legend>
				
				 <!--faire un affiche de tous les medecins , ensuite supprimer à l'aide des checkbox ; le bouton supprimer s'affichera dynamiquement --> 
				<p><input type="submit" value="Afficher Motif" name="afficheMo" />
		</fieldset>
	</form>
	
	
	<form id="formuDirecteur3" action="clinique.php" method="post">
		<fieldset>
				<legend>Créer Médecin</legend>
				
				<p><label> Nom : </label> <input type="text" id="nomMed" name="nomMed" /></p>
				<p><label> Prénom : </label> <input type="text" id="prenomMed" name="prenomMed" /></p>
				<p><label> Spécialité : </label> <input type="text" id="spe" name="spe" /></p>
				<p><input type="submit" value="Créer" name="creerMed" />  <input type="reset" value="Effacer" name="efface" /> </p>
		</fieldset>
		<fieldset>
				<legend>Afficher Médecin</legend>
				
				 <!--faire un affiche de tous les medecins , ensuite supprimer à l'aide des checkbox ; le bouton supprimer s'affichera dynamiquement --> 
				<p><input type="submit" value="Afficher Médecin" name="afficheMed" />
		</fieldset>
	</form>
	<form id="formuDirecteur4" action="clinique.php" method="post">
			<input type="submit" value="Déconnexion" name="deconnecte"/>
	</form>
	</body>
</html>
